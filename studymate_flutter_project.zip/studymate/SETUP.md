# StudyMate — Setup Guide

This gets you from this code drop to a running app in Android Studio.
Follow it in order — each step depends on the one before it.

## What you're getting right now

A working **Class Mode / Ward Mode** app with real email + Google sign-in,
a Firestore-backed profile, and a fully functional **Ask StudyMate** AI
chat screen. Study / Clinical / Create are on the home screen as
"Coming soon" cards — those are the next layers we build together.

## 0. Prerequisites

- [Flutter SDK](https://docs.flutter.dev/get-started/install) (stable channel) installed and `flutter doctor` passing
- Android Studio, with the Flutter/Dart plugins installed
- A Google account (for Firebase)
- Node.js 20+ (only needed for the Cloud Function backend)
- An Anthropic API key from https://console.anthropic.com

## 1. Create the Flutter project shell

I can't run the Flutter toolchain from where I generated this code, so
you'll generate the native platform folders (`android/`, `ios/`,
`web/`, `windows/`) yourself — that's the safest way to get folders
that match *your* exact Flutter version.

```bash
flutter create studymate --platforms=android,ios,web,windows --org com.marvinhsa
```

Now copy everything from this delivered folder **on top of** the
project `flutter create` just made, replacing `pubspec.yaml`,
`lib/main.dart`, and the rest of `lib/` (say yes to overwrite). Keep
the `android/`, `ios/`, `web/`, `windows/` folders `flutter create`
generated — don't replace those.

```bash
flutter pub get
```

## 2. Create your Firebase project

1. Go to https://console.firebase.google.com → **Add project** → name it `StudyMate` (or similar).
2. Install the CLI tools if you don't have them:
   ```bash
   npm install -g firebase-tools
   dart pub global activate flutterfire_cli
   firebase login
   ```
3. From the project root, run:
   ```bash
   flutterfire configure
   ```
   Pick your Firebase project, and select Android, iOS, and Web when
   prompted. This **automatically overwrites**
   `lib/firebase_options.dart` with your real project credentials and
   drops `google-services.json` / `GoogleService-Info.plist` into the
   right native folders. You don't edit that file by hand.

4. In the Firebase console, enable:
   - **Authentication** → Sign-in method → turn on **Email/Password** and **Google**
   - **Firestore Database** → Create database (start in production mode)
   - **Storage** (you'll need this once document upload is built)

5. Deploy the security rules included in this project:
   ```bash
   firebase deploy --only firestore:rules
   ```

## 3. Set up the AI backend (Claude proxy)

**Why a backend at all?** Your Anthropic API key can't live inside the
Flutter app — anyone can decompile an APK and pull strings out of it,
and a leaked key means someone else spends your money. The
`functions/` folder is a tiny Cloud Function that holds your key
server-side; the app only ever talks to *that*, never to Anthropic
directly.

```bash
cd functions
npm install
firebase functions:secrets:set ANTHROPIC_API_KEY
# paste your key from console.anthropic.com when prompted

firebase deploy --only functions
```

This prints a URL like:
```
https://us-central1-studymate-xxxxx.cloudfunctions.net/askClaude
```
Copy it — you'll need it in the next step.

## 4. Run the app

```bash
flutter run --dart-define=STUDYMATE_BACKEND_URL=https://us-central1-studymate-xxxxx.cloudfunctions.net/askClaude
```

In Android Studio, instead of typing that each time: **Run → Edit
Configurations → Additional run args** and paste:
```
--dart-define=STUDYMATE_BACKEND_URL=https://us-central1-studymate-xxxxx.cloudfunctions.net/askClaude
```

Without this, every other screen works fine but **Ask StudyMate**
will show a clear "no backend configured" message instead of crashing.

## 5. Try it

1. Sign up with a real email (Firebase will actually send a
   verification email)
2. Pick Class Mode or Ward Mode
3. Tap **Ask StudyMate** and try: "Explain malaria pathophysiology simply"

## Troubleshooting

- **"DefaultFirebaseOptions have not been configured"** → you skipped
  step 2.3 (`flutterfire configure`).
- **Google sign-in fails on Android** → you need to add your app's SHA-1
  fingerprint in Firebase console → Project settings → Your apps →
  Android app. Get it with `cd android && ./gradlew signingReport`.
- **Ask StudyMate says "no backend configured"** → you launched
  without the `--dart-define` flag from step 4.
- **Cloud Function deploy fails** → make sure billing (Blaze plan) is
  enabled on the Firebase project; secrets and outbound network calls
  from Functions require it. Anthropic API usage itself is billed
  separately by Anthropic.

## What's next

This is deliberately a strong foundation, not the whole spec — the
full feature list (document upload → AI-generated study
guides/PDFs/slides, clinical case reasoning, content library, smart
search, StudyMate Pro subscriptions/payments, analytics, admin
dashboard) gets built as additional layers on this same architecture.
Come back and we'll build the next one.
