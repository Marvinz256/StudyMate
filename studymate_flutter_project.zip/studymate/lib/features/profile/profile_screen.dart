import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_colors.dart';
import '../../models/app_user.dart';
import '../../providers/auth_provider.dart';
import '../../providers/user_provider.dart';
import '../../shared/widgets/app_text_field.dart';
import '../../shared/widgets/primary_button.dart';

class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key});

  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen> {
  final _course = TextEditingController();
  final _year = TextEditingController();
  final _institution = TextEditingController();
  bool _initialized = false;
  bool _saving = false;

  void _hydrate(AppUser user) {
    if (_initialized) return;
    _course.text = user.course;
    _year.text = user.yearOfStudy;
    _institution.text = user.institution;
    _initialized = true;
  }

  Future<void> _save(AppUser user) async {
    setState(() => _saving = true);
    await ref.read(firestoreServiceProvider).updateUserProfile(user.uid, {
      'course': _course.text.trim(),
      'yearOfStudy': _year.text.trim(),
      'institution': _institution.text.trim(),
    });
    if (mounted) {
      setState(() => _saving = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Profile updated')));
    }
  }

  Future<void> _toggleMode(AppUser user) async {
    final newMode =
        user.preferredMode == StudyMode.classMode ? StudyMode.wardMode : StudyMode.classMode;
    await ref.read(firestoreServiceProvider).setPreferredMode(user.uid, newMode);
  }

  @override
  Widget build(BuildContext context) {
    final userAsync = ref.watch(currentUserProfileProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: userAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('$e')),
        data: (user) {
          if (user == null) return const SizedBox.shrink();
          _hydrate(user);

          return SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                CircleAvatar(
                  radius: 36,
                  backgroundColor: AppColors.primaryLight,
                  child: Text(
                    user.firstName.isNotEmpty ? user.firstName[0].toUpperCase() : '?',
                    style: const TextStyle(
                        fontSize: 28, color: AppColors.primary, fontWeight: FontWeight.w700),
                  ),
                ),
                const SizedBox(height: 12),
                Center(
                  child: Text(user.name,
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                ),
                Center(
                  child: Text(user.email,
                      style: const TextStyle(color: AppColors.textSecondary)),
                ),
                const SizedBox(height: 24),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Study mode'),
                  subtitle: Text(user.preferredMode == StudyMode.wardMode
                      ? '🏥 Ward Mode'
                      : '🏫 Class Mode'),
                  trailing: Switch(
                    value: user.preferredMode == StudyMode.wardMode,
                    onChanged: (_) => _toggleMode(user),
                  ),
                ),
                const Divider(height: 32),
                AppTextField(controller: _course, label: 'Course'),
                const SizedBox(height: 16),
                AppTextField(controller: _year, label: 'Year of study'),
                const SizedBox(height: 16),
                AppTextField(controller: _institution, label: 'Institution'),
                const SizedBox(height: 24),
                PrimaryButton(
                  label: 'Save changes',
                  isLoading: _saving,
                  onPressed: () => _save(user),
                ),
                const SizedBox(height: 12),
                OutlinedButton(
                  onPressed: () async {
                    await ref.read(authServiceProvider).signOut();
                    if (context.mounted) context.go('/welcome');
                  },
                  child: const Text('Sign out'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
