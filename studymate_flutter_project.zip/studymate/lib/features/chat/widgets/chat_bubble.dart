import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../models/chat_message.dart';

class ChatBubble extends StatelessWidget {
  final ChatMessage message;
  const ChatBubble({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    final isUser = message.role == ChatRole.user;
    final bgColor = message.isError
        ? AppColors.error.withOpacity(0.08)
        : isUser
            ? AppColors.primary
            : AppColors.surface;
    final textColor = message.isError
        ? AppColors.error
        : isUser
            ? Colors.white
            : AppColors.textPrimary;

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 320),
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(16),
            topRight: const Radius.circular(16),
            bottomLeft: Radius.circular(isUser ? 16 : 4),
            bottomRight: Radius.circular(isUser ? 4 : 16),
          ),
          border: isUser || message.isError
              ? null
              : Border.all(color: AppColors.border),
        ),
        child: Text(
          message.content,
          style: TextStyle(color: textColor, fontSize: 14.5, height: 1.4),
        ),
      ),
    );
  }
}
