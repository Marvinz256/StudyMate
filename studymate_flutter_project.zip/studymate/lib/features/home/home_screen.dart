import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_colors.dart';
import '../../models/app_user.dart';
import '../../providers/user_provider.dart';
import 'widgets/feature_card.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userAsync = ref.watch(currentUserProfileProvider);

    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(
            icon: const Icon(Icons.person_outline),
            onPressed: () => context.push('/profile'),
          ),
        ],
      ),
      body: SafeArea(
        child: userAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Center(child: Text('Something went wrong: $e')),
          data: (user) {
            final mode = user?.preferredMode ?? StudyMode.classMode;
            final greetingName = user?.firstName ?? 'there';

            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
              children: [
                Text(
                  '👋 Good ${_timeOfDay()}, $greetingName',
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 6),
                _ModeChip(mode: mode),
                const SizedBox(height: 24),
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 14,
                  mainAxisSpacing: 14,
                  childAspectRatio: 0.98,
                  children: [
                    FeatureCard(
                      emoji: '📚',
                      title: 'Study',
                      subtitle: 'Explain topics, flashcards, mock exams',
                      color: AppColors.classMode,
                      comingSoon: true,
                    ),
                    FeatureCard(
                      emoji: '🏥',
                      title: 'Clinical',
                      subtitle: 'Ward guides, care plans, OSCE prep',
                      color: AppColors.wardMode,
                      comingSoon: true,
                    ),
                    FeatureCard(
                      emoji: '🎨',
                      title: 'Create',
                      subtitle: 'PDFs, slides, flashcards, leaflets',
                      color: AppColors.secondary,
                      comingSoon: true,
                    ),
                    FeatureCard(
                      emoji: '💬',
                      title: 'Ask StudyMate',
                      subtitle: 'Your AI learning assistant',
                      color: AppColors.primary,
                      onTap: () => context.push('/chat'),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.primaryLight,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.info_outline, color: AppColors.primary),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Study, Clinical, and Create are being built next. '
                          'Ask StudyMate is fully live — try it now.',
                          style: TextStyle(fontSize: 12.5, color: AppColors.textSecondary),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  String _timeOfDay() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Morning';
    if (hour < 17) return 'Afternoon';
    return 'Evening';
  }
}

class _ModeChip extends StatelessWidget {
  final StudyMode mode;
  const _ModeChip({required this.mode});

  @override
  Widget build(BuildContext context) {
    final isWard = mode == StudyMode.wardMode;
    final color = isWard ? AppColors.wardMode : AppColors.classMode;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(isWard ? '🏥' : '🏫', style: const TextStyle(fontSize: 13)),
          const SizedBox(width: 6),
          Text(
            isWard ? 'Ward Mode' : 'Class Mode',
            style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: color),
          ),
        ],
      ),
    );
  }
}
