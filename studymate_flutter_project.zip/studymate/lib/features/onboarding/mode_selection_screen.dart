import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_colors.dart';
import '../../models/app_user.dart';
import '../../providers/auth_provider.dart';
import '../../providers/user_provider.dart';
import '../../shared/widgets/primary_button.dart';

class ModeSelectionScreen extends ConsumerStatefulWidget {
  const ModeSelectionScreen({super.key});

  @override
  ConsumerState<ModeSelectionScreen> createState() =>
      _ModeSelectionScreenState();
}

class _ModeSelectionScreenState extends ConsumerState<ModeSelectionScreen> {
  StudyMode? _selected;
  bool _saving = false;

  Future<void> _continue() async {
    if (_selected == null) return;
    setState(() => _saving = true);
    final uid = ref.read(authStateProvider).value?.uid;
    if (uid != null) {
      await ref
          .read(firestoreServiceProvider)
          .completeOnboarding(uid, _selected!);
    }
    if (mounted) context.go('/home');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 12),
              const Text(
                'Where are you right now?',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 6),
              const Text(
                "You can switch modes anytime from Settings.",
                style: TextStyle(color: AppColors.textSecondary),
              ),
              const SizedBox(height: 28),
              _ModeCard(
                emoji: '🏫',
                title: 'Class Mode',
                description:
                    'I want help understanding lessons, revising, preparing for exams, and simplifying notes.',
                bullets: const [
                  'Topic explanations',
                  'Revision tools',
                  'Flashcards',
                  'Exam preparation',
                ],
                color: AppColors.classMode,
                selected: _selected == StudyMode.classMode,
                onTap: () => setState(() => _selected = StudyMode.classMode),
              ),
              const SizedBox(height: 16),
              _ModeCard(
                emoji: '🏥',
                title: 'Ward Mode',
                description:
                    'I want quick clinical learning support during placement.',
                bullets: const [
                  'Clinical procedures',
                  'Patient assessment',
                  'Nursing care plans',
                  'Ward documentation practice',
                ],
                color: AppColors.wardMode,
                selected: _selected == StudyMode.wardMode,
                onTap: () => setState(() => _selected = StudyMode.wardMode),
              ),
              const Spacer(),
              PrimaryButton(
                label: 'Continue',
                isLoading: _saving,
                onPressed: _selected == null ? null : _continue,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ModeCard extends StatelessWidget {
  final String emoji;
  final String title;
  final String description;
  final List<String> bullets;
  final Color color;
  final bool selected;
  final VoidCallback onTap;

  const _ModeCard({
    required this.emoji,
    required this.title,
    required this.description,
    required this.bullets,
    required this.color,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: selected ? color.withOpacity(0.07) : AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? color : AppColors.border,
            width: selected ? 2 : 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(emoji, style: const TextStyle(fontSize: 26)),
                const SizedBox(width: 10),
                Text(title,
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w700)),
                const Spacer(),
                if (selected) Icon(Icons.check_circle, color: color),
              ],
            ),
            const SizedBox(height: 8),
            Text(description, style: const TextStyle(color: AppColors.textSecondary)),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: bullets
                  .map((b) => Chip(
                        label: Text(b, style: const TextStyle(fontSize: 12)),
                        backgroundColor: color.withOpacity(0.08),
                        side: BorderSide.none,
                        visualDensity: VisualDensity.compact,
                      ))
                  .toList(),
            ),
          ],
        ),
      ),
    );
  }
}
