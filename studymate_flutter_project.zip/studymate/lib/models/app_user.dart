enum StudyMode { classMode, wardMode }

StudyMode studyModeFromString(String? value) {
  switch (value) {
    case 'wardMode':
      return StudyMode.wardMode;
    case 'classMode':
    default:
      return StudyMode.classMode;
  }
}

String studyModeToString(StudyMode mode) =>
    mode == StudyMode.wardMode ? 'wardMode' : 'classMode';

class AppUser {
  final String uid;
  final String name;
  final String email;
  final String course;
  final String yearOfStudy;
  final String institution;
  final StudyMode preferredMode;
  final bool isPremium;
  final bool hasOnboarded;
  final DateTime createdAt;

  const AppUser({
    required this.uid,
    required this.name,
    required this.email,
    this.course = '',
    this.yearOfStudy = '',
    this.institution = '',
    this.preferredMode = StudyMode.classMode,
    this.isPremium = false,
    this.hasOnboarded = false,
    required this.createdAt,
  });

  AppUser copyWith({
    String? name,
    String? course,
    String? yearOfStudy,
    String? institution,
    StudyMode? preferredMode,
    bool? isPremium,
    bool? hasOnboarded,
  }) {
    return AppUser(
      uid: uid,
      name: name ?? this.name,
      email: email,
      course: course ?? this.course,
      yearOfStudy: yearOfStudy ?? this.yearOfStudy,
      institution: institution ?? this.institution,
      preferredMode: preferredMode ?? this.preferredMode,
      isPremium: isPremium ?? this.isPremium,
      hasOnboarded: hasOnboarded ?? this.hasOnboarded,
      createdAt: createdAt,
    );
  }

  factory AppUser.fromMap(String uid, Map<String, dynamic> map) {
    return AppUser(
      uid: uid,
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      course: map['course'] ?? '',
      yearOfStudy: map['yearOfStudy'] ?? '',
      institution: map['institution'] ?? '',
      preferredMode: studyModeFromString(map['preferredMode']),
      isPremium: map['isPremium'] ?? false,
      hasOnboarded: map['hasOnboarded'] ?? false,
      createdAt: DateTime.tryParse(map['createdAt'] ?? '') ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'course': course,
      'yearOfStudy': yearOfStudy,
      'institution': institution,
      'preferredMode': studyModeToString(preferredMode),
      'isPremium': isPremium,
      'hasOnboarded': hasOnboarded,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  /// First name only, used for the "Good Morning, X" greeting.
  String get firstName => name.trim().isEmpty ? 'there' : name.trim().split(' ').first;
}
