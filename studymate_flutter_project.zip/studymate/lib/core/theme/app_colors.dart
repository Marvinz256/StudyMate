import 'package:flutter/material.dart';

/// StudyMate brand palette — "medical blue" on white, premium healthcare feel.
class AppColors {
  AppColors._();

  static const Color primary = Color(0xFF1668E3); // medical blue
  static const Color primaryDark = Color(0xFF0D4CB0);
  static const Color primaryLight = Color(0xFFE8F0FE);

  static const Color secondary = Color(0xFF15B79E); // clinical teal accent
  static const Color secondaryLight = Color(0xFFE3FBF7);

  static const Color background = Color(0xFFFAFBFF);
  static const Color surface = Color(0xFFFFFFFF);

  static const Color textPrimary = Color(0xFF10192B);
  static const Color textSecondary = Color(0xFF5B6478);
  static const Color textMuted = Color(0xFF97A0B3);

  static const Color border = Color(0xFFE7EAF2);

  static const Color success = Color(0xFF1FAE6E);
  static const Color warning = Color(0xFFE3A008);
  static const Color error = Color(0xFFE0452F);

  // Mode accents
  static const Color classMode = Color(0xFF1668E3);
  static const Color wardMode = Color(0xFF15B79E);
}
