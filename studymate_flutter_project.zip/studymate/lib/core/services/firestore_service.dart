import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/app_user.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get _users =>
      _db.collection('users');

  Future<void> createUserProfile(AppUser user) {
    return _users.doc(user.uid).set(user.toMap());
  }

  Future<AppUser?> getUserProfile(String uid) async {
    final doc = await _users.doc(uid).get();
    if (!doc.exists || doc.data() == null) return null;
    return AppUser.fromMap(uid, doc.data()!);
  }

  Stream<AppUser?> watchUserProfile(String uid) {
    return _users.doc(uid).snapshots().map((doc) {
      if (!doc.exists || doc.data() == null) return null;
      return AppUser.fromMap(uid, doc.data()!);
    });
  }

  Future<void> updateUserProfile(String uid, Map<String, dynamic> data) {
    return _users.doc(uid).update(data);
  }

  Future<void> setPreferredMode(String uid, StudyMode mode) {
    return _users.doc(uid).update({
      'preferredMode': studyModeToString(mode),
    });
  }

  /// Saves the chosen mode and marks onboarding complete in one write.
  Future<void> completeOnboarding(String uid, StudyMode mode) {
    return _users.doc(uid).update({
      'preferredMode': studyModeToString(mode),
      'hasOnboarded': true,
    });
  }
}
