import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../models/chat_message.dart';
import '../../models/app_user.dart';
import '../config/env.dart';

/// System prompt that shapes "Ask StudyMate" into a health-science tutor.
/// Adjusts slightly depending on Class Mode vs Ward Mode.
String buildSystemPrompt(StudyMode mode) {
  final base = '''
You are StudyMate, an AI study partner for health science students
(nursing, midwifery, medicine, pharmacy, clinical medicine, medical
lab science, public health, dentistry, physiotherapy, radiography).
Explain things clearly and simply, the way a patient, kind senior
student would. Use short paragraphs, headings, and bullet points
where useful. When asked for exam questions, flashcards, or a care
plan, format them cleanly and completely. Always be medically
accurate and note when something needs verification against current
local clinical guidelines.
''';
  final modeAddendum = mode == StudyMode.wardMode
      ? '''
The student is currently in WARD MODE (on clinical placement). Favor
practical, bedside-applicable answers: clinical reasoning, patient
assessment steps, nursing interventions, and safety-critical points.
'''
      : '''
The student is currently in CLASS MODE (studying/revising). Favor
clear conceptual explanations, structured revision content, and exam
readiness.
''';
  return base + modeAddendum;
}

class ClaudeService {
  /// Sends the running conversation to the backend proxy and returns the
  /// assistant's reply text.
  ///
  /// This calls YOUR backend (see /functions/index.js), never the
  /// Anthropic API directly — the API key must stay server-side.
  Future<String> sendMessage({
    required List<ChatMessage> history,
    required StudyMode mode,
  }) async {
    if (Env.backendUrl.isEmpty) {
      throw ClaudeServiceException(
        'No backend configured. Set STUDYMATE_BACKEND_URL '
        '(see /functions and SETUP.md) before using Ask StudyMate.',
      );
    }

    final messages = history
        .map((m) => {
              'role': m.role == ChatRole.user ? 'user' : 'assistant',
              'content': m.content,
            })
        .toList();

    final response = await http
        .post(
          Uri.parse(Env.backendUrl),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'system': buildSystemPrompt(mode),
            'messages': messages,
          }),
        )
        .timeout(const Duration(seconds: 45));

    if (response.statusCode != 200) {
      throw ClaudeServiceException(
        'StudyMate AI is unavailable right now (${response.statusCode}). '
        'Please try again.',
      );
    }

    final decoded = jsonDecode(response.body) as Map<String, dynamic>;
    final reply = decoded['reply'] as String?;
    if (reply == null || reply.trim().isEmpty) {
      throw ClaudeServiceException('Received an empty response. Please try again.');
    }
    return reply;
  }
}

class ClaudeServiceException implements Exception {
  final String message;
  ClaudeServiceException(this.message);
  @override
  String toString() => message;
}
