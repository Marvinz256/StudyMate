import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../features/auth/forgot_password_screen.dart';
import '../../features/auth/login_screen.dart';
import '../../features/auth/signup_screen.dart';
import '../../features/auth/welcome_screen.dart';
import '../../features/chat/ask_studymate_screen.dart';
import '../../features/home/home_screen.dart';
import '../../features/onboarding/mode_selection_screen.dart';
import '../../features/profile/profile_screen.dart';
import '../../features/splash/splash_screen.dart';
import '../../providers/auth_provider.dart';
import '../../providers/user_provider.dart';

final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authStateProvider);
  final profileState = ref.watch(currentUserProfileProvider);

  return GoRouter(
    initialLocation: '/splash',
    routes: [
      GoRoute(path: '/splash', builder: (_, __) => const SplashScreen()),
      GoRoute(path: '/welcome', builder: (_, __) => const WelcomeScreen()),
      GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
      GoRoute(path: '/signup', builder: (_, __) => const SignUpScreen()),
      GoRoute(
        path: '/forgot-password',
        builder: (_, __) => const ForgotPasswordScreen(),
      ),
      GoRoute(path: '/onboarding', builder: (_, __) => const ModeSelectionScreen()),
      GoRoute(path: '/home', builder: (_, __) => const HomeScreen()),
      GoRoute(path: '/chat', builder: (_, __) => const AskStudyMateScreen()),
      GoRoute(path: '/profile', builder: (_, __) => const ProfileScreen()),
    ],
    redirect: (context, state) {
      final loggedIn = authState.value != null;
      final authLoading = authState.isLoading;
      final path = state.matchedLocation;

      final isAuthRoute =
          ['/welcome', '/login', '/signup', '/forgot-password'].contains(path);

      if (authLoading) return path == '/splash' ? null : '/splash';

      if (!loggedIn) {
        return isAuthRoute ? null : '/welcome';
      }

      // Logged in — never let them sit on splash/auth screens.
      if (path == '/splash' || isAuthRoute) {
        return '/onboarding'; // safe default while profile is still loading
      }

      // Once we know the profile, enforce onboarding completion.
      final profile = profileState.value;
      if (profile != null) {
        if (!profile.hasOnboarded && path != '/onboarding') {
          return '/onboarding';
        }
        if (profile.hasOnboarded && path == '/onboarding') {
          return '/home';
        }
      }

      return null;
    },
    refreshListenable: GoRouterRefreshStream(ref),
  );
});

/// Bridges Riverpod auth + profile streams into a Listenable so GoRouter
/// re-evaluates `redirect` whenever either changes.
class GoRouterRefreshStream extends ChangeNotifier {
  GoRouterRefreshStream(Ref ref) {
    ref.listen(authStateProvider, (_, __) => notifyListeners());
    ref.listen(currentUserProfileProvider, (_, __) => notifyListeners());
  }
}
