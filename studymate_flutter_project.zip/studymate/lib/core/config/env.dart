/// Build-time configuration, injected via --dart-define.
///
/// SECURITY NOTE:
/// Do NOT put your real Anthropic API key here or in any client-side
/// string. Anything shipped inside the compiled app can be extracted.
/// STUDYMATE_BACKEND_URL should point to your own backend (e.g. a
/// Firebase Cloud Function — see /functions in this project) which
/// holds the real Anthropic key server-side and forwards requests.
///
/// Run with, e.g.:
///   flutter run --dart-define=STUDYMATE_BACKEND_URL=https://us-central1-yourproject.cloudfunctions.net/askClaude
class Env {
  Env._();

  static const String backendUrl = String.fromEnvironment(
    'STUDYMATE_BACKEND_URL',
    defaultValue: '',
  );
}
