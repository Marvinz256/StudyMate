import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../core/services/claude_service.dart';
import '../models/app_user.dart';
import '../models/chat_message.dart';
import 'user_provider.dart';

final claudeServiceProvider = Provider<ClaudeService>((ref) => ClaudeService());

class ChatState {
  final List<ChatMessage> messages;
  final bool isSending;

  const ChatState({this.messages = const [], this.isSending = false});

  ChatState copyWith({List<ChatMessage>? messages, bool? isSending}) {
    return ChatState(
      messages: messages ?? this.messages,
      isSending: isSending ?? this.isSending,
    );
  }
}

class ChatController extends StateNotifier<ChatState> {
  final ClaudeService _claude;
  final StudyMode Function() _currentMode;
  static const _uuid = Uuid();

  ChatController(this._claude, this._currentMode) : super(const ChatState());

  Future<void> sendMessage(String text) async {
    final trimmed = text.trim();
    if (trimmed.isEmpty || state.isSending) return;

    final userMessage = ChatMessage(
      id: _uuid.v4(),
      role: ChatRole.user,
      content: trimmed,
      timestamp: DateTime.now(),
    );

    state = state.copyWith(
      messages: [...state.messages, userMessage],
      isSending: true,
    );

    try {
      final reply = await _claude.sendMessage(
        history: state.messages,
        mode: _currentMode(),
      );
      final assistantMessage = ChatMessage(
        id: _uuid.v4(),
        role: ChatRole.assistant,
        content: reply,
        timestamp: DateTime.now(),
      );
      state = state.copyWith(
        messages: [...state.messages, assistantMessage],
        isSending: false,
      );
    } catch (e) {
      final errorMessage = ChatMessage(
        id: _uuid.v4(),
        role: ChatRole.assistant,
        content: e.toString(),
        timestamp: DateTime.now(),
        isError: true,
      );
      state = state.copyWith(
        messages: [...state.messages, errorMessage],
        isSending: false,
      );
    }
  }

  void clear() => state = const ChatState();
}

final chatControllerProvider =
    StateNotifierProvider<ChatController, ChatState>((ref) {
  final claude = ref.watch(claudeServiceProvider);
  final userAsync = ref.watch(currentUserProfileProvider);
  return ChatController(
    claude,
    () => userAsync.value?.preferredMode ?? StudyMode.classMode,
  );
});
