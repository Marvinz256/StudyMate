import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/services/firestore_service.dart';
import '../models/app_user.dart';
import 'auth_provider.dart';

final firestoreServiceProvider =
    Provider<FirestoreService>((ref) => FirestoreService());

/// Live-streams the signed-in user's Firestore profile document.
final currentUserProfileProvider = StreamProvider<AppUser?>((ref) {
  final authState = ref.watch(authStateProvider);
  final firebaseUser = authState.value;
  if (firebaseUser == null) return Stream.value(null);
  return ref.watch(firestoreServiceProvider).watchUserProfile(firebaseUser.uid);
});
