# StudyMate

> "Turn your notes into your smartest study partner."

An AI-powered study companion for health science students (nursing,
midwifery, medicine, pharmacy, clinical medicine, lab science, public
health, dentistry, physiotherapy, radiography).

## Status

**Foundation build.** Working right now:

- Firebase email/password + Google authentication, with email verification and password reset
- Firestore-backed user profile (course, year, institution)
- Class Mode / Ward Mode onboarding, switchable anytime from Profile
- Home screen with the full card layout from the product spec
- **Ask StudyMate** — a live AI chat tutor (Claude), mode-aware, calling a secure backend proxy (not a hardcoded key)

Not built yet (see SETUP.md → "What's next"): document upload/processing,
the content generation engine (PDF/PPT/infographic export), clinical
case-reasoning mode, library/search, StudyMate Pro subscriptions,
analytics, notifications, admin dashboard.

## Architecture

```
lib/
  core/
    config/      build-time config (backend URL via --dart-define)
    router/       go_router setup with auth + onboarding redirects
    services/     AuthService, FirestoreService, ClaudeService
    theme/        colors + Material 3 theme
  models/         AppUser, ChatMessage
  providers/      Riverpod providers/state notifiers
  features/
    splash/ auth/ onboarding/ home/ chat/ profile/
  shared/widgets/ reusable buttons, text fields
functions/         Firebase Cloud Function — Claude API proxy
firestore.rules    Firestore security rules
```

State management: **Riverpod**. Routing: **go_router**, driven by auth
state (`FirebaseAuth`) and profile state (`Firestore`) so redirects
happen automatically — no manual navigation logic scattered around
screens.

## Getting started

See **SETUP.md** for the full walkthrough (Flutter project creation →
Firebase → Cloud Function → run in Android Studio).

## Security notes

- The Anthropic API key never ships inside the app — it lives in a
  Firebase Functions secret and is only reachable through
  `functions/index.js`.
- Firestore rules restrict each user to reading/writing only their
  own profile document, and block client-side privilege escalation
  (a user can't set `isPremium: true` on themselves).
