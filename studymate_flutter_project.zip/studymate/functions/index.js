/**
 * StudyMate backend proxy for the Claude API.
 *
 * WHY THIS EXISTS:
 * A Flutter app ships as a compiled binary that users can decompile.
 * Any API key embedded in it can be extracted and abused (people WILL
 * find it and run up your Anthropic bill). This tiny Cloud Function
 * keeps your real API key on the server and only exposes a narrow
 * endpoint the app is allowed to call.
 *
 * DEPLOY:
 *   1. cd functions && npm install
 *   2. firebase functions:secrets:set ANTHROPIC_API_KEY
 *      (paste your key when prompted)
 *   3. firebase deploy --only functions
 *   4. Copy the resulting URL into --dart-define=STUDYMATE_BACKEND_URL=...
 */

const { onRequest } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");

const ANTHROPIC_API_KEY = defineSecret("ANTHROPIC_API_KEY");

const MODEL = "claude-sonnet-4-6";
const MAX_TOKENS = 1500;

exports.askClaude = onRequest(
  { secrets: [ANTHROPIC_API_KEY], cors: true, region: "us-central1" },
  async (req, res) => {
    if (req.method !== "POST") {
      res.status(405).json({ error: "Use POST" });
      return;
    }

    const { system, messages } = req.body || {};

    if (!Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ error: "messages[] is required" });
      return;
    }

    // Basic guardrails: cap history length and message size so one
    // request can't blow up your token spend.
    const trimmedMessages = messages.slice(-20).map((m) => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0, 6000),
    }));

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": ANTHROPIC_API_KEY.value(),
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: MODEL,
          max_tokens: MAX_TOKENS,
          system: typeof system === "string" ? system.slice(0, 4000) : undefined,
          messages: trimmedMessages,
        }),
      });

      if (!response.ok) {
        const errText = await response.text();
        console.error("Anthropic error", response.status, errText);
        res.status(502).json({ error: "Upstream AI error" });
        return;
      }

      const data = await response.json();
      const textBlock = (data.content || []).find((b) => b.type === "text");
      res.status(200).json({ reply: textBlock ? textBlock.text : "" });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Server error" });
    }
  }
);
